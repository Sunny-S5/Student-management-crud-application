package com.symbiosis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.symbiosis.entity.Student;
import com.symbiosis.service.StdService;

import jakarta.servlet.http.HttpSession;

@org.springframework.stereotype.Controller
public class Controller 
{
	@Autowired 
	private StdService service;
	
	
//	@GetMapping("/index")
	@RequestMapping(value="/index",method=RequestMethod.GET)

public String home(Model m)
{

		List<Student> std=service.getAllStd();
			m.addAttribute("std",std);
		
	return "index";
}
	@GetMapping("/addstd")
    public String addstd() 
    {
	
		return "add_student";
    }
	
	@PostMapping("/register")
	public String register(@ModelAttribute Student s,HttpSession session) 
	{
		System.out.println(s);
		service.addstd(s);
		session.setAttribute("msg", "student added successfully");
	return 	"redirect:/";
	}
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable int id,Model m) 
	{
		Student s=service.getStdbyId(id);
		m.addAttribute("std",s);
		return "edit";
	}
	@PostMapping("/update")
	public String updatestd(@ModelAttribute Student s,HttpSession session) 
	{
		service.addstd(s);
		session.setAttribute("msg","Student Data updated successfully...");
		return "redirect:/index";
	}
	@GetMapping("/delete/{id}")
	public String deletestd(@PathVariable int id,HttpSession session) 
	{
		service.deletestd(id);
		session.setAttribute("msg","Std Data deleted successfully...");
		return "redirect:/";
	}
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String login(ModelMap model,@RequestParam String username,@RequestParam String password) 
	{
		if(username.equals("sunny") && password.equals("123")) 
		{
			return "login";
		}
		model.put("errormsg","please provide correct username and password");
		return "index";
	}
	
}
